# Integration Test Debug Bundle: full-regression-2026-07-09_035254

**Temporary artefact** for investigating a Full Regression failure. Safe to delete once the investigation concludes.

## Run summary

| Field | Value |
|-------|-------|
| Run summary file | `results/full-regression-2026-07-09_035254.json` |
| Mode | FullRegression |
| Start time | 2026-07-08 20:36:41 |
| End time | 2026-07-09 03:52:54 |
| Wall-clock duration | 07:16:13 (~7.3 hrs) |
| DirectoryType | OpenLDAP |
| ChangeTracking | Enabled |
| ExportConcurrency | null (default) |
| ContinueOnFailure | false |
| OverallSuccess | **false** |
| Failing scenario | **Scenario14-AttributePriority** (Template Nano, ExitCode 1) |

13 scenarios ran (Scenario1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14). The first 12 passed; Scenario14 failed after 00:03:36. `ContinueOnFailure` was false, so the run stopped at the failure.

Note on templates: scenarios use per-scenario templates. Scenarios 1, 5, 7, 8, 9 ran under `Scale100k50Groups`; the rest under `Nano`. This is why filenames carry different template tags within the one run.

## The failure

Scenario14-AttributePriority failed because the **JIM Worker threw an unhandled exception during a full sync run** and marked the activity as failed.

- Activity ID: `019f4501-ada7-7eab-8d9b-7157771f27cf`
- Timestamp: `2026-07-09T03:52:48.84Z`
- Exception: `Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException` - "The database operation was expected to affect 1 row(s), but actually affected 0 row(s); data may have been modified or deleted since entities were loaded." (optimistic concurrency conflict)

Stack trace (top JIM frames):
```
JIM.PostgresData.Repositories.MetaverseRepository.UpdateMetaverseObjectsAsync   src/JIM.PostgresData/Repositories/MetaverseRepository.cs:916
JIM.Worker.Processors.SyncTaskProcessorBase.PersistPendingMetaverseObjectsAsync src/JIM.Worker/Processors/SyncTaskProcessorBase.cs:1616
JIM.Worker.Processors.SyncFullSyncTaskProcessor.PerformFullSyncAsync            src/JIM.Worker/Processors/SyncFullSyncTaskProcessor.cs:267
JIM.Worker.Worker...ExecuteAsync                                                src/JIM.Worker/Worker.cs:329
```

The worker then logged: `TryFailActivityOnFreshContextAsync: Marked activity 019f4501-... as failed via a fresh context` (Warning).

### Where to look first
- Worker log `results/logs/worker/jim.worker.20260709.log`, line ~31581 (the full `@x` stack trace and surrounding sync context). This is Serilog CLEF (JSON-per-line); grep the ActivityID `019f4501-ada7-7eab-8d9b-7157771f27cf` to trace the whole activity.
- `results/errors-Scenario14-AttributePriority-Nano-2026-07-09_034953.log` - the one-line error surfaced to the scenario.
- `results/logs/Scenario14-AttributePriority-Nano-2026-07-09_034951.log` - the scenario harness log (test assertions, stage timings).

### Re-run command (from the scenario log)
```
jim-reset && pwsh ./test/integration/Run-IntegrationTests.ps1 -Scenario "Scenario14-AttributePriority" -Template Nano -DirectoryType OpenLDAP -LogLevel Information -ExportConcurrency 16
```

## Bundle contents (121 files)

Per-scenario artefacts (each of the 13 scenarios has most of these):
- `results/logs/<Scenario>...log` - scenario harness log
- `results/logs/worker/jim.worker.2026070{8,9}.log` - **worker service application logs** spanning the run (CLEF JSON). NB: daily rolling files, so they also contain pre/post-run content for that day.
- `results/performance/cc0176c47345/<Scenario>...json` - performance metrics
- `results/volume-audit-<Scenario>...log` - volume audit log
- `results/docker-events-<Scenario>...log` (+ `.stderr`) - Docker events
- `results/docker-stats-<Scenario>...csv` (+ `.stderr.log` / `.stdout.log`) - Docker container stats
- `results/errors-<Scenario>...log` - errors surfaced per scenario
- `results/test-results/Scenario4-DeletionRules-...json` - (only Scenario4 emitted one)
- `results/full-regression-2026-07-09_035254.json` - the overall run summary

## Selection method / provenance

Files were selected by modification time within the run window (2026-07-08 20:36:41 -> 2026-07-09 03:52:54). Six files that fell in the window by mtime but belong to a **different, immediately-preceding run** were deliberately excluded: a prior successful `full-regression-2026-07-08_203640.json` (StartTime 2026-07-08 17:57:01, DirectoryType SambaAD) and its Scenario13 artefacts (filename timestamp `2026-07-08_2034xx`), which finished one second before this run began.
